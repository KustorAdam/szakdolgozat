export default function menu() {
    return (
        <h1>kigyo
        </h1>
    )
   
}