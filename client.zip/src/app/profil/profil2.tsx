import page from '@/app/profil/page'
import { Col, Row } from 'react-bootstrap'

