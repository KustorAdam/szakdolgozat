export default function menu() {
    return (
        <h1>menü
        </h1>
    )
   
}