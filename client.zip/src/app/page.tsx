import { Container } from "react-bootstrap";
import React from "react";

export default function Home() {
  return (
    <h2>Sidebar</h2>
  )
}